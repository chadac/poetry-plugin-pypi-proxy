# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['sample_project']

package_data = \
{'': ['*']}

install_requires = \
['sample-dependency>=0.0.1,<0.0.2']

setup_kwargs = {
    'name': 'sample-project',
    'version': '0.1.0',
    'description': 'Testing Poetry',
    'long_description': 'Test Project\n',
    'author': 'Chad Crawford',
    'author_email': 'chadcr@amazon.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
